// Copyright SAEVUS. Todos los derechos reservados.

#pragma once

#include "CoreMinimal.h"
#include "Combate/SAEVUSParadaGolpe.h"
#include "Combate/SAEVUSTiposCombate.h"
#include "Components/ActorComponent.h"
#include "SAEVUSComponenteCombate.generated.h"

class ACharacter;
class USAEVUSComponenteMovimiento;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FSAEVUSFirmaGolpeAtaque, AActor*, ActorGolpeado, float, Danio);
DECLARE_MULTICAST_DELEGATE(FSAEVUSEventoAtaque);
DECLARE_MULTICAST_DELEGATE_OneParam(FSAEVUSEventoImpactoAtaque, const FSAEVUSDefinicionAtaque& /*Ataque*/);

/**
 * Base del cuerpo a cuerpo: ejecuta las líneas de tiempo de ataque de un repertorio, guarda las
 * pulsaciones en buffer, encadena combos, aplica golpes y decide cuándo una acción de movimiento
 * puede cancelar un ataque.
 *
 * Los efectos de movimiento (estocada, velocidad reducida en el suelo, giro) pasan por
 * USAEVUSComponenteMovimiento, que se actualiza después de este componente. Ver Documentos/combate.md.
 */
UCLASS(ClassGroup = (SAEVUS), meta = (BlueprintSpawnableComponent))
class SAEVUS_API USAEVUSComponenteCombate : public UActorComponent
{
	GENERATED_BODY()

public:
	USAEVUSComponenteCombate();

	/** Pulsación de ataque frontal; empieza o encadena un ataque en cuanto se pueda. */
	UFUNCTION(BlueprintCallable, Category = "SAEVUS|Combate")
	void PedirAtaque();

	/** Pulsación de ataque en una dirección. Arriba y abajo no encadenan; abajo en el suelo es frontal. */
	UFUNCTION(BlueprintCallable, Category = "SAEVUS|Combate")
	void PedirAtaqueEnDireccion(ESAEVUSDireccionAtaque Direccion);

	/** El botón de ataque se mantiene (cierto) o se suelta (falso): carga el ataque cargado. */
	void FijarAtaqueMantenido(bool bMantenido);

	/** Pierde la carga sin lanzar el ataque cargado (cambio a un arma de fuego, muerte). */
	void CancelarCarga();

	/** La carga está lista: soltar lanza el ataque cargado. */
	UFUNCTION(BlueprintPure, Category = "SAEVUS|Combate")
	bool EstaCargado() const { return bAtaqueMantenido && TiempoCargando >= ObtenerRepertorio().TiempoCarga; }

	/** Progreso de la carga, de 0 a 1 (para efectos). */
	float ObtenerProgresoCarga() const;

	bool EsAtaqueCargado() const { return bAtaqueCargado; }

	/** Dirección de una pulsación según la inclinación vertical de la cámara (grados, positivo = arriba). */
	ESAEVUSDireccionAtaque DireccionSegunInclinacion(float InclinacionGrados) const;

	/**
	 * Pregunta si una acción de movimiento puede ocurrir ahora. Sin atacar: sí. Atacando: solo
	 * dentro de la ventana de cancelación del ataque para esa acción, y entonces el ataque termina.
	 */
	bool IntentarCancelarPor(ESAEVUSAccionCancelacion Accion);

	UFUNCTION(BlueprintPure, Category = "SAEVUS|Combate")
	bool EstaAtacando() const { return bAtacando; }

	/** Corta el ataque en curso sin más (muerte, cambio de repertorio). */
	void TerminarAtaque();

	UFUNCTION(BlueprintPure, Category = "SAEVUS|Combate")
	ESAEVUSFaseAtaque ObtenerFaseAtaque() const;

	/** El ataque en curso, o nulo. */
	const FSAEVUSDefinicionAtaque* ObtenerAtaqueActual() const { return bAtacando ? &AtaqueEnCurso : nullptr; }

	/** Posición del ataque en curso en su cadena (0 = primero), o INDEX_NONE. */
	int32 ObtenerIndiceCombo() const { return IndiceCombo; }
	bool EsCadenaAerea() const { return bCadenaAerea; }
	bool EsTajoEnCarrera() const { return bTajoEnCarrera; }
	ESAEVUSDireccionAtaque ObtenerDireccionAtaque() const { return DireccionAtaque; }
	bool EstaEnParadaGolpe() const { return ParadaGolpe.EstaActiva(); }
	float ObtenerTiempoAtaque() const { return TiempoAtaque; }
	bool TieneAtaqueEnBuffer() const { return TiempoBufferAtaqueRestante > 0.f; }

	const FSAEVUSRepertorioMelee& ObtenerRepertorio() const;

	/**
	 * Cierto si Punto cae en el abanico de Ataque con origen Origen (centro del cuerpo a AlturaGolpe)
	 * mirando a Frente (horizontal). Función pura: la usan la detección y los tests.
	 */
	static bool DentroDelAbanico(const FSAEVUSDefinicionAtaque& Ataque, const FVector& Origen, const FVector& Frente, const FVector& Punto);

	/**
	 * El abanico del ataque en curso mientras está activo, para dibujarlo: origen, frente, avance de la
	 * fase activa (0–1) y sentido del barrido (+1 de derecha a izquierda, −1 al revés). Falso si no hay.
	 */
	bool ObtenerAbanicoActivo(FVector& OutOrigen, FVector& OutFrente, float& OutAvance, float& OutSentido) const;

	/** Cambia el repertorio. Nulo vuelve al del código. Termina un ataque en curso. */
	void FijarRepertorio(const USAEVUSDatosRepertorioMelee* NuevoRepertorio);

	/** Se emite al empezar cada ataque (sonido, efectos). */
	FSAEVUSEventoAtaque AlIniciarAtaque;

	/** Se dispara una vez por cada actor golpeado (que pierde vida) por un ataque, con el daño hecho. */
	UPROPERTY(BlueprintAssignable, Category = "SAEVUS|Combate")
	FSAEVUSFirmaGolpeAtaque AlGolpear;

	/** Se emite una vez por ataque, en su primer contacto (con lo que sea): retroceso del brazo, sacudida. */
	FSAEVUSEventoImpactoAtaque AlImpactar;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

protected:
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	/** Repertorio opcional; sin él se usan los valores por defecto de FSAEVUSRepertorioMelee. */
	UPROPERTY(EditDefaultsOnly, Category = "SAEVUS|Combate")
	TObjectPtr<const USAEVUSDatosRepertorioMelee> DatosRepertorio;

private:
	/** Empieza o encadena un ataque si la pulsación en buffer se puede usar ya. */
	void ProcesarAtaqueEnBuffer();
	/** Los ataques empiezan en el suelo o en el aire, no en paredes; un dash puede cortarse para atacar. */
	bool PuedeAtacarAhora() const;
	void IniciarAtaque(bool bEnAire, int32 Indice);
	void IniciarAtaqueDireccional(bool bEnAire, ESAEVUSDireccionAtaque Direccion);
	/** Tajo en carrera: el ataque que sale de un dash, en la dirección del dash. */
	void IniciarTajoEnCarrera(bool bEnAire, const FVector& DireccionDash);
	/** Qué ataque es: posición en su cadena, cadena aérea, dirección, tajo en carrera o cargado. */
	void FijarContexto(int32 Indice, bool bEnAire, ESAEVUSDireccionAtaque Direccion, bool bCarrera, bool bCargado);
	/** Pone en marcha el ataque: giro, estocada y escala de velocidad (hacia DireccionForzada si se da). */
	void PrepararAtaque(const FSAEVUSDefinicionAtaque& Ataque, const FVector* DireccionForzada = nullptr);
	void DetectarGolpes(const FSAEVUSDefinicionAtaque& Ataque);
	/** Retroceso, empuje, rebote y parada de golpe del primer acierto de un ataque. */
	void AplicarImpacto(const FSAEVUSDefinicionAtaque& Ataque, TConstArrayView<AActor*> Golpeados);
	/** Dirección en la que el ataque en curso empuja a lo que golpea. */
	FVector DireccionEmpuje(const AActor* Objetivo) const;

	ACharacter* ObtenerPersonaje() const;
	USAEVUSComponenteMovimiento* ObtenerMovimiento() const;

	/** Copia del ataque en curso (válida mientras bAtacando). */
	FSAEVUSDefinicionAtaque AtaqueEnCurso;
	bool bAtacando = false;
	int32 IndiceCombo = INDEX_NONE;
	bool bCadenaAerea = false;
	float TiempoAtaque = 0.f;
	float TiempoBufferAtaqueRestante = 0.f;
	ESAEVUSDireccionAtaque DireccionAtaque = ESAEVUSDireccionAtaque::Frontal;
	ESAEVUSDireccionAtaque DireccionPedida = ESAEVUSDireccionAtaque::Frontal;
	/** El impacto (retroceso, rebote, parada) se aplica una vez por ataque, en su primer acierto. */
	bool bImpactoAplicado = false;
	bool bTajoEnCarrera = false;
	bool bAtaqueCargado = false;
	bool bAtaqueMantenido = false;
	float TiempoCargando = 0.f;
	FSAEVUSParadaGolpe ParadaGolpe;

	/** Actores ya golpeados por el ataque en curso; cada uno recibe un golpe por ataque. */
	TArray<TWeakObjectPtr<AActor>> ActoresGolpeados;
};
