// Copyright SAEVUS. Todos los derechos reservados.

#include "Audio/SAEVUSSintesis.h"
#include "Math/RandomStream.h"
#include "Misc/ScopeLock.h"
#include "Sound/SoundWaveProcedural.h"

namespace SAEVUSSintesis
{
	// Forma de la onda áspera: el seno se satura hacia una cuadrada.
	constexpr float GananciaSaturacion = 8.f;
	constexpr float MaximoInt16 = 32767.f;

	TArray<int16> Sintetizar(const FSAEVUSSonidoSintetizado& Sonido, int32 Muestreo)
	{
		const int32 Numero = FMath::Max(1, FMath::RoundToInt32(Sonido.Duracion * Muestreo));
		TArray<int16> Muestras;
		Muestras.SetNumUninitialized(Numero);

		FRandomStream Aleatorio(Sonido.Semilla);
		float Fase = 0.f;
		float RuidoFiltrado = 0.f;
		for (int32 Indice = 0; Indice < Numero; ++Indice)
		{
			const float Tiempo = static_cast<float>(Indice) / Muestreo;
			const float Fraccion = static_cast<float>(Indice) / Numero;

			const float Envolvente = Tiempo < Sonido.Ataque
				? Tiempo / FMath::Max(Sonido.Ataque, UE_KINDA_SMALL_NUMBER)
				: FMath::Exp(-(Tiempo - Sonido.Ataque) / Sonido.Caida);

			const float Frecuencia = FMath::Lerp(Sonido.FrecuenciaInicio, Sonido.FrecuenciaFin, Fraccion);
			Fase += UE_TWO_PI * Frecuencia / Muestreo;
			const float Seno = FMath::Sin(Fase);
			const float Saturada = FMath::Clamp(Seno * GananciaSaturacion, -1.f, 1.f);
			const float Tono = FMath::Lerp(Seno, Saturada, Sonido.Aspereza);

			RuidoFiltrado += Sonido.FiltroRuido * (Aleatorio.FRandRange(-1.f, 1.f) - RuidoFiltrado);
			const float Valor = FMath::Lerp(Tono, RuidoFiltrado, Sonido.MezclaRuido) * Envolvente * Sonido.Volumen;
			Muestras[Indice] = static_cast<int16>(FMath::Clamp(Valor, -1.f, 1.f) * MaximoInt16);
		}
		return Muestras;
	}

	/** Huella de un sonido: dos sonidos con los mismos datos suenan igual (la semilla también va). */
	uint32 Huella(const FSAEVUSSonidoSintetizado& Sonido)
	{
		uint32 Resultado = GetTypeHash(Sonido.Semilla);
		for (const float Valor : { Sonido.Duracion, Sonido.FrecuenciaInicio, Sonido.FrecuenciaFin, Sonido.Aspereza, Sonido.MezclaRuido,
			Sonido.FiltroRuido, Sonido.Ataque, Sonido.Caida, Sonido.Volumen })
		{
			Resultado = HashCombine(Resultado, GetTypeHash(Valor));
		}
		return Resultado;
	}

	TArray<uint8> SintetizarBytes(const FSAEVUSSonidoSintetizado& Sonido)
	{
		// Los enemigos del mismo tipo piden los mismos sonidos: se sintetizan una vez y se copian.
		static TMap<uint32, TArray<uint8>> Cache;
		static FCriticalSection Cerrojo;
		const uint32 Clave = Huella(Sonido);
		{
			FScopeLock Bloqueo(&Cerrojo);
			if (const TArray<uint8>* Guardado = Cache.Find(Clave))
			{
				return *Guardado;
			}
		}
		const TArray<int16> Muestras = Sintetizar(Sonido);
		TArray<uint8> Bytes;
		Bytes.SetNumUninitialized(Muestras.Num() * sizeof(int16));
		FMemory::Memcpy(Bytes.GetData(), Muestras.GetData(), Bytes.Num());
		FScopeLock Bloqueo(&Cerrojo);
		Cache.Add(Clave, Bytes);
		return Bytes;
	}

	USoundWaveProcedural* CrearOnda(UObject* Propietario, const TArray<uint8>& Datos, float Duracion)
	{
		USoundWaveProcedural* Onda = NewObject<USoundWaveProcedural>(Propietario);
		Onda->SetSampleRate(FrecuenciaMuestreo);
		Onda->NumChannels = 1;
		Onda->Duration = Duracion;
		Onda->bLooping = false;
		Onda->QueueAudio(Datos.GetData(), Datos.Num());
		return Onda;
	}
}
